package org.capstore.rest.service;

import java.util.List;

import org.capstore.rest.model.Customer;

public interface IPasswordService {

	public List<Customer> getAllCustomers();

}
